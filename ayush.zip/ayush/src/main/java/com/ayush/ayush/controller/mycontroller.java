package com.ayush.ayush.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ayush.ayush.entity.load;
import com.ayush.ayush.services.loadservice;

@RestController
public class mycontroller {

    @Autowired
    private loadservice loadserv;
    @GetMapping("/load")
    public List<load> getload()
    {
        return this.loadserv.getload();
    }

    @GetMapping("/load/{loadid}")
    public load getload(@PathVariable int loadid)
    {
            return this.loadserv.getload(loadid);
    }

    @PostMapping("/load")
    public load addcourse(@RequestBody load load)
    {
        return this.loadserv.addcourse(load);
    }

    @PutMapping("/load/{loadid}")
    public load updateBook(@RequestBody load load ,@PathVariable int loadid)
    {
        this.loadserv.updateeBook(load , loadid);
        return load;
    }

    @DeleteMapping("/load/{loadid}")
    public void deleteLoad(@PathVariable int loadid)
    {
        this.loadserv.deleteLoad(loadid);
    }


}
