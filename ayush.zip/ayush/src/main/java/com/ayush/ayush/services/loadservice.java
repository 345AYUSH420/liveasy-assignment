package com.ayush.ayush.services;

import java.util.List;

import com.ayush.ayush.entity.load;

public interface loadservice {
     public List<load> getload();
     public load getload(int loadid);
      public load addcourse(load load);
      public void updateeBook(load load , int loadid);
      public void deleteLoad(int loadid);
    
    
}
