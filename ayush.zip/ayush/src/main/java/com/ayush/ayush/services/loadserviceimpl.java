package com.ayush.ayush.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.ayush.ayush.entity.load;
@Service
public class loadserviceimpl implements loadservice {

    List<load> list;

    public loadserviceimpl()
    {
        list = new ArrayList<>();
        list.add(new load("delhi", "jaipur", "chemicals", "canter",1,100,1));
    }

    @Override
    public List<load> getload() {
        return list;
        
    }

    @Override
    public load getload(int loadid) {
        load lo = null;
        for(load l :list)
        {
            if(l.getShipperId() == loadid)
            {
               lo = l;
               break;
            }
        }

        return lo;
    }

    @Override
    public load addcourse(load load) {
        list.add(load);
        return load;
       
    }

    @Override
    public void updateeBook(load load, int loadid) {

       list = list.stream().map(b->{
        if(b.getShipperId() == loadid)
        {
            b.setLoadingPoint(load.getLoadingPoint());
            b.setUnloadingPoint(load.getUnloadingPoint());
        }
        return b;
       }).collect(Collectors.toList());
    }

    @Override
    public void deleteLoad(int loadid) {

       list =  list.stream().filter(l->{
            if(l.getShipperId()!=loadid)
            {
                return true;
            }
            else{
                return false;
            }
        }).collect(Collectors.toList());
        
    }
    
}
