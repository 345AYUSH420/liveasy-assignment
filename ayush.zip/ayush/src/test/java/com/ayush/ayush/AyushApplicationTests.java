package com.ayush.ayush;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AyushApplicationTests {

	@Test
	void contextLoads() {
	}

}
